#ifndef __UTILS_MATRICE__
#define __UTILS_MATRICE__

matrice construit_matrice(int l, int c, double *donnees);
void affiche_matrice(matrice m);
matrice lit_matrice(char *fichier);

#endif
