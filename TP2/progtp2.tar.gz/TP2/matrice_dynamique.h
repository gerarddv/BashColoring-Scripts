#ifndef __MATRICE_DYNAMIQUE__
#define __MATRICE_DYNAMIQUE__

struct donnees_matrice;

typedef struct donnees_matrice *matrice;

#include "matrice_operations.h"
#endif
