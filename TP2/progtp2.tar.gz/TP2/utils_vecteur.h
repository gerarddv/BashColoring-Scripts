#ifndef __UTILS_VECTEUR__
#define __UTILS_VECTEUR__
#include <stdio.h>

vecteur alloue_vecteur_et_teste(int taille);
void affiche_vecteur(vecteur v);
vecteur lit_vecteur(FILE *f);

#endif
